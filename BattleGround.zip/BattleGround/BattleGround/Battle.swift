//
//  Battle.swift
//  BattleGround
//
//  Created by MacStudent on 2020-02-24.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import Foundation

class Battle
{
    var teams = [Team]()
    var index:Int = 0
    
    func getTeam(a:Int)-> Team {
        return self.teams[a]
    }
    func addTeam(a:Team)->Void {
        self.teams.append(a)
    }
    func conflict(a:Team, b:Team)-> Bool{
        var dist: Double
        dist = sqrt((a.center.0-b.center.0)*(a.center.0-b.center.0)+(a.center.1-b.center.1)*(a.center.1-b.center.1))
        
        a.radius = a.players.count * 10
        b.radius = b.players.count * 10
        if(dist < Double(a.radius) + Double(b.radius) ){
            return true
        }
        return false
    }
    func war(a: Team,  b: Team )-> Void{
        let T = a.fight(otherTeam: b)
        for i in (0..<teams.count){
            if(self.teams[i] === T){
                index = i
                
            }
            self.teams.remove(at: index)
        }
        
        
    }
    
    
    
    
    
}
