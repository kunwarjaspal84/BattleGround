//
//  Player.swift
//  BattleGround
//
//  Created by MacStudent on 2020-02-24.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import Foundation

class Player{
    
    
    var health : Int
    var team : Team
    var name : String
    var damage:Int
    
    init(a : Team,b: String) {
        
        self.health = 100
        self.team = a
        self.name = b
        self.damage = 20
        
        
    }
    func setName(a:String)->(){
        self.name = a
    }
    func getName()->String{
        return self.name
    }
    func getDamage()-> Int{
        return self.damage
    }
    func setDamage(a:Int)->Void{
        self.damage = a
    }
    func setTeam(a : Team) -> Void {
        
        self.team = a
        
    }
    
    func setHealth(a : Int)-> Void {
        
        self.health = a
        
    }
    
    func getTeam()->Team{
        
        return self.team
    }

    func getHealth()-> Int{
        return self.health
    }
    
    func attack(otherPlayer: Player)-> Void{
        let pr:String = "Player \(self.name) is fighting with \(otherPlayer.getName())"
        print(pr)
        self.health = self.health - otherPlayer.getDamage()
        otherPlayer.health = otherPlayer.health - self.getDamage()
        
    }
    
    
}
