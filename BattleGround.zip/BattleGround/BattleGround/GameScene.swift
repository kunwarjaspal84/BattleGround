//
//  GameScene.swift
//  BattleGround
//
//  Created by MacStudent on 2020-02-24.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation

class GameScene: SKScene {
    var i = 1
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    var team1 : SKSpriteNode?
    var team2 : SKSpriteNode?
 
 
    override func didMove(to view: SKView) {
       
        team1 = childNode(withName: "Team1") as? SKSpriteNode
        team2 = childNode(withName: "Team2") as? SKSpriteNode

    }
  
   func creatTeam() {
       let shape1 = SKShapeNode()
       shape1.path = UIBezierPath(roundedRect: CGRect(x: -100, y: -100, width: 80, height: 80), cornerRadius: 64).cgPath
       shape1.position = CGPoint(x: frame.midX, y: frame.midY)
       shape1.fillColor = UIColor.red
       shape1.strokeColor = UIColor.blue
       shape1.lineWidth = 10
       addChild(shape1)
         
        let  position = CGPoint(x:0 , y:0)
        shape1.position = CGPoint(x:300 , y:300)
        let moveLeft = SKAction.move(to: position, duration: 20)
        
        shape1.run(SKAction.sequence([moveLeft, SKAction.removeFromParent()]))
    }
       
        func creatTeam2() {
        
            let shape = SKShapeNode()
            shape.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width: 80, height: 80), cornerRadius: 64).cgPath
            shape.position = CGPoint(x: frame.midX, y: frame.midY)
            shape.fillColor = UIColor.red
            shape.strokeColor = UIColor.blue
            shape.lineWidth = 5
            addChild(shape)
            let  position1 = CGPoint(x:0.0 , y:0.0)
            shape.position = CGPoint(x:-50, y:200)
            let moveLeft1 = SKAction.move(to: position, duration: 20)
            shape.run(SKAction.sequence([moveLeft1, SKAction.removeFromParent()]))
        
}
    
    func creatTeam3()
    {
    let shape3 = SKShapeNode()
               shape3.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width: 60, height: 60), cornerRadius: 64).cgPath
               shape3.position = CGPoint(x: frame.midX, y: frame.midY)
               shape3.fillColor = UIColor.red
               shape3.strokeColor = UIColor.blue
               shape3.lineWidth = 5
               addChild(shape3)
               let  position2 = CGPoint(x:0.0 , y:0.0)
               shape3.position = CGPoint(x:-40, y:-200)
               let moveLeft2 = SKAction.move(to: position, duration: 20)
               shape3.run(SKAction.sequence([moveLeft2, SKAction.removeFromParent()]))
        
    }
    
            func creatTeam4() {
            
                let shape4 = SKShapeNode()
                shape4.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width: 80, height: 80), cornerRadius: 64).cgPath
                shape4.position = CGPoint(x: frame.midX, y: frame.midY)
                shape4.fillColor = UIColor.red
                shape4.strokeColor = UIColor.blue
                shape4.lineWidth = 5
                addChild(shape4)
                let  position3 = CGPoint(x:0.0 , y:0.0)
                shape4.position = CGPoint(x:250, y:-200)
                let moveLeft1 = SKAction.move(to: position, duration: 20)
                shape4.run(SKAction.sequence([moveLeft1, SKAction.removeFromParent()]))
            
    }

            func creatTeam5() {
            
                let shape5 = SKShapeNode()
                shape5.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width: 80, height: 80), cornerRadius: 64).cgPath
                shape5.position = CGPoint(x: frame.midX, y: frame.midY)
                shape5.fillColor = UIColor.red
                shape5.strokeColor = UIColor.blue
                shape5.lineWidth = 5
                addChild(shape5)
                let  position4 = CGPoint(x:0.0 , y:0.0)
                shape5.position = CGPoint(x:-250, y:20)
                let moveLeft1 = SKAction.move(to: position, duration: 20)
                shape5.run(SKAction.sequence([moveLeft1, SKAction.removeFromParent()]))
            
    }


    
    
    
     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
          // creatTeam();
        if (i==1){
        creatTeam2();
        creatTeam3() ;
        creatTeam();
        creatTeam4();
        creatTeam5();
            i+=1
        }
      
    }
     
          
  /* func creatTeam4 ()
   {
    
    let shape4 = SKShapeNode()
               shape4.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width: 25, height: 25), cornerRadius: 64).cgPath
               shape4.position = CGPoint(x: frame.midX, y: frame.midY)
               shape4.fillColor = UIColor.red
               shape4.strokeColor = UIColor.blue
               shape4.lineWidth = 10
               addChild(shape4)
               let  position3 = CGPoint(x:0.0 , y:0.0)
               shape4.position = CGPoint(x:-30, y:300)
               let moveLeft3 = SKAction.move(to: position, duration: 20)
               shape4.run(SKAction.sequence([moveLeft3, SKAction.removeFromParent()]))
}*/
           
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
    
    
    
    func playSound() {
        guard let url = Bundle.main.url(forResource: "sound", withExtension: "mp3") else {
            print("url not found")
            return
        }

        do {
            /// this codes for making this app ready to takeover the device audio
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)

            /// change fileTypeHint according to the type of your audio file (you can omit this)

            /// for iOS 11 onward, use :
           let player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)

            /// else :
            /// player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3)

            // no need for prepareToPlay because prepareToPlay is happen automatically when calling play()
            player.play()
        } catch let error as NSError {
            print("error: \(error.localizedDescription)")
        }
    }
    
}


    
    


