//
//  Team.swift
//  BattleGround
//
//  Created by MacStudent on 2020-02-24.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import Foundation

class Team{
    
    
    
    var players = [Player]()
    var color: String
    var radius : Int
    var center : (Double,Double)
    var playerdead : Int = 0
    
    init() {
        
        self.center = (Double.random(in: 0...1000),Double.random(in: 0...1000))
        self.color = ""
        self.radius = 0
    }
    
    func addPlayer(a : Player) -> Void{
        
        self.players.append(a)
        
        
    }
    
    func getColor() -> String{
        
        return self.color
    }
    
    func getRadius()->Int{
        
        return self.radius
    }
    
    func getCenter()->(Double,Double) {
        
        
        return self.center
    }
    
    func getPlayerDead()->Int {
        
        
        return self.playerdead
    }
    
    func getPlayer() -> [Player]{
        
        return self.players
        
        
    }
    func fight(otherTeam: Team)-> Team{
        var i,k: Int
        var temp =  self
        i = self.getPlayerDead()
        k = otherTeam.getPlayerDead()
        while i<self.players.count && k<otherTeam.players.count {
            self.players[i].attack(otherPlayer: otherTeam.players[k])
            if(self.players[i].getHealth()<=0)
            {
                print("Player \(self.players[i].getName()) is dead")
                self.playerdead += 1;
                i+=1
            }
            else if (otherTeam.players[k].getHealth()<=0)
            {
                print("Player \(otherTeam.players[k]) is dead")
                otherTeam.playerdead += 1
                k += 1
            }
        }
        if(i >= self.players.count)
        {
            temp = self
            
        }
        else if(k >= otherTeam.players.count)
        {
            temp = otherTeam
        }
        return temp
    }

    
    
    
    
   
    
    
    
    
    
    
    
    
}



